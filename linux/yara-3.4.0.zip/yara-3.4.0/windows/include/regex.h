#ifndef _REGEX_H
#define _REGEX_H 1

# include <pcre.h>
# include <pcreposix.h>

#endif /* _REGEX_H */
