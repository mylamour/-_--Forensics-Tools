
/* Name of package */
#define PACKAGE "yara"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "vmalvarez@virustotal.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "yara"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "yara 3.4.0"

/* Define to the version of this package. */
#define PACKAGE_VERSION "3.4.0"

/* Version number of package */
#define VERSION "3.4.0"
